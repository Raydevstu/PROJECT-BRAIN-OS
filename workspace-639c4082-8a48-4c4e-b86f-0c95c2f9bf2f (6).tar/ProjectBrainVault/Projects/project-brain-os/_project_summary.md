# Project Brain OS — Compressed Project Brain

- **Health Score:** 92/100 (EXCELLENT)
- **Unique Captures Indexed:** 100 (142 observed occurrences after duplicate folding)
- **Composition:** 58 notes, 0 screenshots, 21 terminal logs
- **Decisions Logged:** 25
- **Last Compressed:** 2026-10-25T22:22:03.498Z

## 1. Compressed Rolling Memory (Tier-1 Prompt Payload)
Compressed memory for **Project Brain OS** (100 captures: 58 notes, 21 terminals, 21 sessions; auto-synthesized by the Memory Compression Daemon).

## Current Focus
Active themes across recent captures: note, quick, thought, use, session, 22, probe, 3000.

## Recent Activity (last 14 days)
- 100 captures on record.
- Latest work session: Work Session 2026-10-25 · 21:29–22:21 · 65 captures

## Active Decisions (do not violate)
- **Decision: use SQLite sidecar for vectors in agent-probe-1792**: Decision: use SQLite sidecar for vectors in agent-probe-1792966922843 (Reason: keeps Brain OS dependency-light)
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j (Reason: Zero-config, portable, single .db file per blueprint)
- **Decision: use SQLite sidecar for vectors in agent-probe-1792**: Decision: use SQLite sidecar for vectors in agent-probe-1792966902592 (Reason: keeps Brain OS dependency-light)
- **Decision: use SQLite sidecar for vectors in agent-probe-1792**: Decision: use SQLite sidecar for vectors in agent-probe-1792966888578 (Reason: keeps Brain OS dependency-light)
- **Decision: use SQLite sidecar for vectors in agent-probe-1792**: Decision: use SQLite sidecar for vectors in agent-probe-1792966877190 (Reason: keeps Brain OS dependency-light)

#

## 2. Key Architectural Decisions
- **Decision: use SQLite sidecar for vectors in agent-probe-179296692**: Decision: use SQLite sidecar for vectors in agent-probe-1792966922843 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296690**: Decision: use SQLite sidecar for vectors in agent-probe-1792966902592 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296688**: Decision: use SQLite sidecar for vectors in agent-probe-1792966888578 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296687**: Decision: use SQLite sidecar for vectors in agent-probe-1792966877190 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296680**: Decision: use SQLite sidecar for vectors in agent-probe-1792966802020 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296679**: Decision: use SQLite sidecar for vectors in agent-probe-1792966794812 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296672**: Decision: use SQLite sidecar for vectors in agent-probe-1792966724932 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296666**: Decision: use SQLite sidecar for vectors in agent-probe-1792966664038 *(Reason: keeps Brain OS dependency-light)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296654**: Decision: use SQLite sidecar for vectors in agent-probe-1792966546551 *(Reason: keeps Brain OS dependency-light)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296635**: Decision: use SQLite sidecar for vectors in agent-probe-1792966354330 *(Reason: keeps Brain OS dependency-light)*
- **Decision: use SQLite sidecar for vectors in agent-probe-179296625**: Decision: use SQLite sidecar for vectors in agent-probe-1792966255281 *(Reason: keeps Brain OS dependency-light)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*
- **Verification: SQLite over Neo4j**: Use SQLite + FTS5 instead of standalone Neo4j *(Reason: Zero-config, portable, single .db file per blueprint)*

## 3. Known Bug Fixes & Actionable Remedies
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`
- Error: Port 3000 already in use (EADDRINUSE) -> `npx kill-port 3000`

## 4. Knowledge Gaps & Recommendations
- ⚠️ Unresolved error captures piling up — 20 error captures have no logged fix — log the fix or decision that resolved them

## 5. Key Files
- architecture.md, sync-probe.md, notes.md

_Topics: note, quick, thought, use, session, 22, probe, 3000_
